% This code produces a parameter set for the menstrual cycle model.

function par_est

clear all;
format long


load par_IG.mat par_IG			% loads initial guess for parameter set

parameters = par_IG;

%parameter arrangement = [kLH; V0LH; V1LH; KmLH;  KiLHP; cLHE; cLHP; VFSH; kFSH; cFSHE; KiFSHInh; cFSHP; b; c1; c2; c3; c4; d1; d2; 
%                k1; k2; k3; k4; alpha; gamma; e0; e1; e2; e3; p1; p2; h0; h1; h2; h3; w; q; RPLH0; LH0; RPFSH0; FSH0;
%                RcF0; GrF0; DomF0; Sc10; Sc20; Lut10; Lut20; Lut30; Lut40];

parameters = sqrt(parameters);

   
xdata = [0:111]';
lut = [12; 14; 15; 14; 17; 17; 19; 18; 17; 17; 17; 25; 50; 123; 41; 22; 
            20; 20; 18; 16; 12; 9; 11; 10; 11; 11; 11; 11];
fol = [11.4; 11.6; 11.7; 12.4; 12.6; 11.3; 12.1; 11.3; 10.0; 8.7; 8.6; 8.2;
            10.4; 19.6; 12.1; 9.2; 8.7; 8.6; 7.4; 7.2; 6.1; 5.4; 5.2; 5.4; 5.3;
            6.1; 6.7; 8.3];       
est = [51; 55; 53; 59; 60; 62; 66; 72; 95; 119; 138; 188; 237; 215; 127; 91; 
            102; 119; 140; 133; 152; 142; 140; 155; 133; 114; 70; 55];
pro = [1.1; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.7; 1.2; 
            2.0; 5.0; 8.9; 11.2; 15.6; 17.3; 17.9; 17.2; 14.4; 12.6; 10.3; 8.1;
            4.3; 1.9];
inh = [1.0; 1.1; 1.0; 1.1; 1.1; 1.0; 1.1; 1.2; 1.7; 2.3; 3.2; 4.5; 7.4; 9.3; 
            7.7; 8.1; 10.1; 8.9; 9.5; 11.5; 9.1; 8.7; 7.5; 6.6; 5.7; 4.1; 
            2.2; 1.7];
        
LHdata = [lut; lut; lut; lut];
FSHdata = [fol; fol; fol; fol];
E2data = [est; est; est; est];
P4data = [pro; pro; pro; pro];
Inhdata = [inh; inh; inh; inh];


opts = optimset('MaxIter',5000,'MaxFunEvals',5000);
[optimal_par, ~, ~, ~] = fminsearch(@fminmerged,parameters,opts);


parameters = optimal_par;
parameterssquared = parameters.^2		% optimal parameter set


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ls,sol] = fminmerged(parameters)


xdata = [0:111]';
lut = [12; 14; 15; 14; 17; 17; 19; 18; 17; 17; 17; 25; 50; 123; 41; 22; 
            20; 20; 18; 16; 12; 9; 11; 10; 11; 11; 11; 11];
fol = [11.4; 11.6; 11.7; 12.4; 12.6; 11.3; 12.1; 11.3; 10.0; 8.7; 8.6; 8.2;
            10.4; 19.6; 12.1; 9.2; 8.7; 8.6; 7.4; 7.2; 6.1; 5.4; 5.2; 5.4; 5.3;
            6.1; 6.7; 8.3];       
est = [51; 55; 53; 59; 60; 62; 66; 72; 95; 119; 138; 188; 237; 215; 127; 91; 
            102; 119; 140; 133; 152; 142; 140; 155; 133; 114; 70; 55];
pro = [1.1; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.6; 0.7; 1.2; 
            2.0; 5.0; 8.9; 11.2; 15.6; 17.3; 17.9; 17.2; 14.4; 12.6; 10.3; 8.1;
            4.3; 1.9];
inh = [1.0; 1.1; 1.0; 1.1; 1.1; 1.0; 1.1; 1.2; 1.7; 2.3; 3.2; 4.5; 7.4; 9.3; 
            7.7; 8.1; 10.1; 8.9; 9.5; 11.5; 9.1; 8.7; 7.5; 6.6; 5.7; 4.1; 
            2.2; 1.7];
        
LHdata = [lut; lut; lut; lut];
FSHdata = [fol; fol; fol; fol];
E2data = [est; est; est; est];
P4data = [pro; pro; pro; pro];
Inhdata = [inh; inh; inh; inh];


solution = solve_mod(parameters)';
LH = solution(:,2);
FSH = solution(:,4);
GrF = solution(:,6);
DomF = solution(:,7);
Lut2 = solution(:,11);
Lut3 = solution(:,12);
Lut4 = solution(:,13);

parameterssquared = parameters.^2;

E2  = (parameterssquared(26))  + ((parameterssquared(27)))*GrF  + ((parameterssquared(28)))*DomF  + ...
        ((parameterssquared(29)))*Lut4;
P4  = ((parameterssquared(30)))*Lut3  + ((parameterssquared(31)))*Lut4;
Inh = (parameterssquared(32)) + ((parameterssquared(33)))*DomF + ((parameterssquared(34)))*Lut2 + ...
        ((parameterssquared(35)))*Lut3;


error1 = ((E2 - E2data)./E2data);
Z1 = sqrt(abs(zscore(est)));

for i = 0:3 
    error1((1 + i*28):(12+ i*28)) = error1((1+ i*28):(12+ i*28));
    error1(13+ i*28) = Z1(13).*error1(13+ i*28);
    error1((14 + i*28):(28+ i*28)) = error1((14+ i*28):(28+ i*28));
end
ls1 = (error1'*error1)*(1/(112-50));


error2 = ((P4 - P4data)./P4data);
Z2 = sqrt(abs(zscore(pro)));
for i = 0:3 
    error2((1 + i*28):(20+ i*28)) = error2((1+ i*28):(20+ i*28));
    error2(21+ i*28) = Z2(21).*error2(21+ i*28);
    error2((22 + i*28):(28+ i*28)) = error2((22+ i*28):(28+ i*28));
end
ls2 = (error2'*error2)*(1/(112-50));


error3 = ((Inh - Inhdata)./Inhdata);
Z3 = sqrt(abs(zscore(inh)));
for i = 0:3 
    error2((1 + i*28):(19+ i*28)) = error2((1+ i*28):(19+ i*28));
    error2(20+ i*28) = Z3(20).*error2(20+ i*28);
    error2((21 + i*28):(28+ i*28)) = error2((21+ i*28):(28+ i*28));
end
ls3 = (error3'*error3)*(1/(112-50));


error4 = ((LH - LHdata)./LHdata);            
Z4 = sqrt(abs(zscore(lut)));
for i = 0:3 
    error4((1 + i*28):(13+ i*28)) = error4((1+ i*28):(13+ i*28));
    error4(14+ i*28) = Z4(14).*error4(14+ i*28);
    error4((15 + i*28):(28+ i*28)) = error4((15+ i*28):(28+ i*28));
end
ls4 = (error4'*error4)*(1/(112-50));


error5 = ((FSH - FSHdata)./FSHdata);         
Z5 = sqrt(abs(zscore(fol)));
for i = 0:3 
    error5((1 + i*28):(13+ i*28)) = error5((1+ i*28):(13+ i*28));
    error5(14+ i*28) = Z5(14).*error5(14+ i*28);
    error5((15 + i*28):(28+ i*28)) = error5((15+ i*28):(28+ i*28));
end
ls5 = (error5'*error5)*(1/(112-50));


ls = ls1 + ls2 + ls3 + ls4 + ls5;

end


function [solution] = solve_mod(parameters)

x    = 0:1:111;
tdata = [0 111];
Init = (parameters(38:50)).^2;
param = (parameters(1:37)).^2;
dInh =  1.5; 

solution = dde23(@model, dInh, Init, tdata, [], param);
solution = deval(solution, x);

end



function dstate = model(t, state, delay, param)

kLH =       param(1); 
V0LH =   	param(2); 
V1LH =  	param(3); 
KmLH =  	param(4);                          
KiLHP =  	param(5); 
cLHE =  	param(6); 
cLHP =  	param(7); 
VFSH =   	param(8); 
kFSH =  	param(9); 
cFSHE = 	param(10); 
KiFSHInh = 	param(11);            
cFSHP = 	param(12);
b =         param(13);
c1 =        param(14); 
c2 =        param(15); 
c3 =        param(16); 
c4 =        param(17); 
d1 =        param(18); 
d2 =        param(19); 
k1 =        param(20); 
k2 =        param(21); 
k3 =        param(22); 
k4 =        param(23); 
alpha =     param(24); 
gamma =     param(25); 
e0 =        param(26);  
e1 =        param(27);
e2 =        param(28); 
e3 =        param(29); 
p1 =        param(30);
p2 =        param(31); 
h0 =        param(32);  
h1 =        param(33); 
h2 =        param(34); 
h3 =        param(35); 
w =         param(36);
q =         param(37);






RPLH        =  state(1); 
LH          =  state(2); 
RPFSH       =  state(3); 
FSH         =  state(4); 
RcF         =  state(5);   
GrF         =  state(6);
DomF         =  state(7);
Sc1         =  state(8);
Sc2         =  state(9);
Lut1        =  state(10);
Lut2        =  state(11);
Lut3        =  state(12);
Lut4        =  state(13); 

E2              =    e0 + e1*GrF + e2*DomF + e3*Lut4;
P4              =    p1*Lut3 + p2*Lut4;

statelag1       = delay(:,1);

DomFdelayInh     = statelag1(7);
Lut2delayInh    = statelag1(11);
Lut3delayInh    = statelag1(12);


InhdelayInh     = h0 + h1*DomFdelayInh + h2*Lut2delayInh + h3*Lut3delayInh;



dRPLHdt     =   ((V0LH + (V1LH*E2^8/(KmLH^8 + E2^8)))/(1 + (P4/KiLHP))) - ((kLH*(1 + cLHP*P4)*RPLH)/(1 + cLHE*E2));
dLHdt       =   (1/2.5)*((kLH*(1 + cLHP*P4)*RPLH)/(1 + cLHE*E2)) - 14*LH;
dRPFSHdt    =   (VFSH/(1 + (InhdelayInh/KiFSHInh) + (P4/w))) - ((kFSH*(1 + cFSHP*P4)*RPFSH)/(1 + cFSHE*E2^2));
dFSHdt      =   (1/2.5)*((kFSH*(1 + cFSHP*P4)*RPFSH)/(1 + cFSHE*E2^2)) -  8.21*FSH;  
dRcFdt      =   (b + c1*RcF)*(FSH/(1 + (P4/q))) - c2*(LH^alpha)*RcF;
dGrFdt      =    c2*(LH^alpha)*RcF - c3*LH*GrF; 
dDomFdt     =    c3*LH*GrF - c4*(LH^gamma)*DomF;
dSc1dt      =    c4*(LH^gamma)*DomF - d1*Sc1;
dSc2dt      =    d1*Sc1 - d2*Sc2;
dLut1dt     =    d2*Sc2 - k1*Lut1;
dLut2dt     =    k1*Lut1 - k2*Lut2;
dLut3dt     =    k2*Lut2 - k3*Lut3;
dLut4dt     =    k3*Lut3 - k4*Lut4;



dstate      = zeros(13,1);

dstate(1)   = dRPLHdt;
dstate(2)   = dLHdt;
dstate(3)   = dRPFSHdt;
dstate(4)   = dFSHdt;
dstate(5)   = dRcFdt;
dstate(6)   = dGrFdt;
dstate(7)   = dDomFdt;
dstate(8)   = dSc1dt;
dstate(9)   = dSc2dt;
dstate(10)  = dLut1dt;
dstate(11)  = dLut2dt;
dstate(12)  = dLut3dt;
dstate(13)  = dLut4dt;

end
    
    
    
    
    
 


